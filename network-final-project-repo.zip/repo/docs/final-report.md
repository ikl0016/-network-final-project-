# Final Project Report: Virtual Computer Network Design and Implementation

**Author:** Isaac Lindsay Jr.

## 1. Project Overview

This report documents the design, configuration, testing, and demonstration of a small virtual computer network built to illustrate core networking concepts including DHCP, DNS, ARP, HTTP/HTTPS, ICMP, IP addressing, NAT, TCP, and UDP. The network was implemented using Cisco Packet Tracer, with all devices, services, and protocol interactions configured and verified through direct testing.

## 2. Network Design Explanation

The network consists of an internal LAN segment connected to a simulated external/Internet segment through a router configured for NAT. The internal segment includes a switch connecting a DHCP/DNS server, a web server, and two client PCs. Client devices receive their IP configuration automatically via DHCP, resolve hostnames via the internal DNS server, and communicate with the web server using HTTP/HTTPS.

## 3. Network Topology Diagram

![Network topology](../images/topology-diagram.svg)

## 4. IP Addressing Table

See [ip-addressing-table.md](ip-addressing-table.md).

## 5. Configuration Screenshots

**Router configuration (interface addressing and NAT):**

`![Router config](../images/screenshots/router-config.png)`

**DHCP server configuration:**

`![DHCP config](../images/screenshots/dhcp-config.png)`

**DNS server configuration:**

`![DNS config](../images/screenshots/dns-config.png)`

**Web server configuration:**

`![Web server config](../images/screenshots/web-server-config.png)`

## 6. Protocol Demonstrations

Captured and analyzed using Packet Tracer's Simulation Mode PDU inspection:

- DHCP — client lease request and acknowledgment
- DNS — hostname-to-IP resolution query and response
- ARP — MAC address resolution during first communication
- ICMP — ping and traceroute connectivity verification
- TCP — connection-oriented handshake during HTTP session
- UDP — connectionless communication observed during DNS lookup
- HTTP/HTTPS — client request and server response, including SSL/TLS negotiation

`![Protocol capture](../images/screenshots/protocol-capture.png)`

## 7. Testing Results

- Ping from Client PC 1 to router gateway (192.168.1.1): _pending_
- Ping from Client PC 1 to web server (192.168.1.20): _pending_
- Ping using hostname (DNS resolution test): _pending_
- Traceroute to web server: _pending_
- Browser HTTP request to web server: _pending_

`![Test results](../images/screenshots/test-results.png)`

## 8. Challenges Faced and Solutions Implemented

_Describe any configuration issues encountered (e.g. DHCP not assigning addresses, DNS record errors, NAT misconfiguration, cabling/port errors) and how each was resolved._

## 9. Conclusion

The completed project demonstrates a fully functional virtual network in which devices communicate using real networking protocols and services. It shows how DHCP, DNS, NAT, and HTTP/HTTPS interact at the packet level to support reliable client-server communication.
