# IP Addressing Table

| Device            | Role                          | IP Address     | Subnet |
|-------------------|--------------------------------|----------------|--------|
| Router            | Gateway / NAT                  | 192.168.1.1    | /24    |
| Switch            | Layer 2 switching              | N/A            | N/A    |
| DHCP/DNS Server   | IP assignment, name resolution | 192.168.1.10   | /24    |
| Web Server        | HTTP/HTTPS hosting             | 192.168.1.20   | /24    |
| Client PC 1       | End-user device                | DHCP assigned  | /24    |
| Client PC 2       | End-user device                | DHCP assigned  | /24    |

DHCP pool: `192.168.1.100` – `192.168.1.150` (adjust to match your actual configuration).

DNS record: `www.mynetwork.local` → `192.168.1.20`
