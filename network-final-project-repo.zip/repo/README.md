# Virtual Computer Network Final Project

Design, configuration, testing, and demonstration of a small virtual computer network built in Cisco Packet Tracer, illustrating DHCP, DNS, ARP, HTTP/HTTPS, ICMP, IP addressing, NAT, TCP, and UDP.

**Author:** Isaac Lindsay Jr.

## Overview

This project implements an internal LAN segment connected to a simulated external/Internet segment through a router configured for NAT. The internal segment includes a switch connecting a DHCP/DNS server, a web server, and two client PCs. Client devices receive IP configuration automatically via DHCP, resolve hostnames via the internal DNS server, and communicate with the web server over HTTP/HTTPS.

## Repository structure

```
.
├── README.md                     This file
├── docs/
│   ├── final-report.md           Full write-up: design, testing, protocol demos, challenges
│   └── ip-addressing-table.md    Device roles and addressing plan
├── images/
│   ├── topology-diagram.svg      Network topology diagram
│   └── screenshots/              Configuration and test evidence (add your PNGs here)
└── network.pkt                   Packet Tracer project file (add after export)
```

## Network topology

See [`images/topology-diagram.svg`](images/topology-diagram.svg).

Router → Switch → DHCP/DNS server, Web server, Client PC 1, Client PC 2, all on `192.168.1.0/24`.

## Tools used

- Cisco Packet Tracer — network simulation and device configuration
- Simulation Mode PDU inspection — protocol-level packet analysis (ARP, DHCP, DNS, ICMP, TCP, HTTP)

## Documentation

- [Final report](docs/final-report.md)
- [IP addressing table](docs/ip-addressing-table.md)

## Status

- [ ] Topology built
- [ ] Router configured (NAT, interface addressing)
- [ ] DHCP/DNS server configured
- [ ] Web server configured
- [ ] Connectivity tested (ping, traceroute, DNS, HTTP)
- [ ] Protocols captured in Simulation Mode
- [ ] Demo video recorded
